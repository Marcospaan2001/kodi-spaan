# Krispijn Video 1.2.5

Gebaseerd op POV 6.11.03 van kodifitzwell, GPL-3.0.
Broncode: https://github.com/Marcospaan2001/kodi-spaan
Bouw: tools/make_pov.py, aanpassingen: video-mod/.
Eigen addon-id, Nederlands startmenu, beperkte lokale opstartservice,
Nederlandse metadata en middelgrote afbeeldingen.
Upstream: https://raw.githubusercontent.com/kodifitzwell/repo/2c8390c6e65213853a862a00044597946b946132/plugin.video.pov/plugin.video.pov-6.11.03.zip
SHA256: 9ac93ad045910774503cbfeeb45b63bbd9b23837c9e76749885076c9b11edfba
